(* Paclet Info File *)

(* created 2011/06/03*)

Paclet[
    Name -> "GroupExt",
    Version -> "1.0.0",
    MathematicaVersion -> "8+",
    Description -> "Group Theory Extensions for Mathematica 8",
    Creator -> "Gergely Nagy",
    Extensions -> 
        {
            {"Kernel", Context -> "GroupExt`"}, 
            {"Documentation", Language -> "English"}
        }
]


